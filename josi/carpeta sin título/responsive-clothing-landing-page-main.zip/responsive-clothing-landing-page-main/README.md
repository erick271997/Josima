# 👕 Responsive Clothing Landing Page
## [Watch it on youtube](https://youtu.be/UgE8hcbRVBU)
### 👕 Responsive Clothing Landing Page 

- Responsive Clothing Landing Page Using HTML CSS & JavaScript
- Contains animations when scrolling.
- Includes a dark and light mode.
- Smooth scrolling in each section.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/c/Bedimcode)

![preview img](/preview.png)
